package com.fau.loginzaceapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * SeatLocation  is responsible for displaying the google maps location
 * @author Alicia Mitchell
 */
public class SeatLocation extends FragmentActivity implements OnMapReadyCallback {
    //GOOGLE MAP
    private GoogleMap mGMap;
    SupportMapFragment mapFragment;
    GPSTracker gps;
    Button Return;
    Button update;
    private static final String TAG = "Dashboard";
    private Double number1, number2;
    TextView TVlat, TVlon;
    public Double LatVal;
    public Double LonVal;
    public String Val1;
    public Double xyz;

    //CoordinateDatabase coordinateDatabase;
    //Coordinates coordinates;


    String LOG_TAG = SeatLocation.class.getSimpleName();
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String LAT = "latKey";
    public static final String LON = "lonKey";
    SharedPreferences sharedpreferences;
    public String savedVal1;
    public static String check;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_location);
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);
//        Intent intent = getIntent();
//        String message = intent.getStringExtra(Dashboard.EXTRA_MESSAGE);
//        Intent intent2 = getIntent();
//        String message2 = intent2.getStringExtra(Dashboard.EXTRA_MESSAGE);
//        System.out.println("Lat "+message);
//        System.out.println("Lon "+message2);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        //new GPSTracker(SeatLocation.this);
        TVlat = findViewById(R.id.textViewLat);
        TVlon = findViewById(R.id.textViewLon);


    /*    FirebaseFirestore db = FirebaseFirestore.getInstance();
        final DocumentReference documentReference2 = db.collection("GPSresult").document("Values");
        final FirebaseDatabase database4 = FirebaseDatabase.getInstance();
        DatabaseReference myRef55 = database4.getReference();
        DatabaseReference myRef77 = database4.getReference();


        myRef55 = myRef55.child("Username").child("GPS").child("Latitude");
        myRef55.keepSynced(true);
        myRef55.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                Double value44 =  dataSnapshot.getValue(Double.class);
                LatVal = value44;
                getGMlat(value44);
                DecimalFormat df1 = new DecimalFormat("#.##");
                df1.format(value44);
                TVlat.setText("Lat:  "+df1.format(value44));
                check = String.valueOf(value44);
                System.out.println("SHARED PREF VALUE DATA ON CHANGE = "+check);
                //TVlat.setText("26.46644");
                savedVal1 = "26.46644";
                sharedpreferences = getPreferences(Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("26.46644", check);
                editor.commit();
                documentReference2.update("LatGM",value44);
                if (value44 instanceof Double) {
                    System.out.println("object is a Double");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });

        sharedpreferences = getPreferences(Context.MODE_PRIVATE);
        String shvalue = sharedpreferences.getString("26.46644",check);
        System.out.println("SHARED PREF VALUE = "+check);

        //System.out.println("global value "+x);
        myRef77 = myRef77.child("Username").child("GPS").child("Longitude");
        myRef77.keepSynced(true);
        final DocumentReference documentReference = db.collection("GPSresult").document("Values");
        myRef77.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                Double value66 =  dataSnapshot.getValue(Double.class);
          *//*      getGMlon(value66);
                SimpleGetterAndSetter obj = new SimpleGetterAndSetter();
                obj.number2 = value66;
                obj.setNumber2(value66);
                System.out.println("For Lon "+obj.number2);*//*
                //LatRes.setText("Lat:  "+value66);
                LonVal = value66;
                DecimalFormat df1 = new DecimalFormat("#.##");
                df1.format(value66);
                TVlon.setText("Lon:  "+df1.format(value66));
                //TVlon.setText("-80.32221");


                documentReference.update("LonGM", value66 );
                System.out.println("From Database "+LonVal);
                //documentReference.update("LonGM", value66 );
                //System.out.println("From Database "+LonVal);
//                SharedPreferences sp = getSharedPreferences("key", 0);
//                SharedPreferences.Editor sedt = sp.edit();
//                sedt.putString(value66, txtEvent.getText().toString());
//                sedt.putString("txtopertaive", txtOperative.getText().toString());
//                sedt.commit();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });*/



        //Return Button
        Return = (Button) findViewById(R.id.button3);

        //GOOGLE MAPS
       mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


//        Return.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent inToDash = new Intent(getApplicationContext(), Dashboard.class);
//                startActivity(inToDash);
//                finish();
//
//            }
//        });

        update= findViewById(R.id.buttonUp);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //other db calls
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                final DocumentReference documentReference2 = db.collection("GPSresult").document("Values");
                final FirebaseDatabase database4 = FirebaseDatabase.getInstance();
                DatabaseReference myRef55 = database4.getReference();
                DatabaseReference myRef77 = database4.getReference();


                myRef55 = myRef55.child("Username").child("GPS").child("Latitude");
                myRef55.keepSynced(true);
                myRef55.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //Getting the string value of that node
                        Double value44 =  dataSnapshot.getValue(Double.class);
                        LatVal = value44;
                        getGMlat(value44);
                        DecimalFormat df1 = new DecimalFormat("#.##");
                        df1.format(value44);
                        TVlat.setText("Lat:  "+df1.format(value44));
                        check = String.valueOf(value44);
                        System.out.println("SHARED PREF VALUE DATA ON CHANGE = "+check);
                        //TVlat.setText("26.46644");
                        savedVal1 = "26.46644";
                        sharedpreferences = getPreferences(Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedpreferences.edit();
                        editor.putString("26.46644", check);
                        editor.commit();
                        documentReference2.update("LatGM",value44);
                        if (value44 instanceof Double) {
                            System.out.println("object is a Double");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

                    }
                });

                sharedpreferences = getPreferences(Context.MODE_PRIVATE);
                String shvalue = sharedpreferences.getString("26.46644",check);
                System.out.println("SHARED PREF VALUE = "+check);

                //System.out.println("global value "+x);
                myRef77 = myRef77.child("Username").child("GPS").child("Longitude");
                myRef77.keepSynced(true);
                final DocumentReference documentReference = db.collection("GPSresult").document("Values");
                myRef77.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //Getting the string value of that node
                        Double value66 =  dataSnapshot.getValue(Double.class);
          /*      getGMlon(value66);
                SimpleGetterAndSetter obj = new SimpleGetterAndSetter();
                obj.number2 = value66;
                obj.setNumber2(value66);
                System.out.println("For Lon "+obj.number2);*/
                        //LatRes.setText("Lat:  "+value66);
                        LonVal = value66;
                        DecimalFormat df1 = new DecimalFormat("#.##");
                        df1.format(value66);
                        TVlon.setText("Lon:  "+df1.format(value66));
                        //TVlon.setText("-80.32221");


                        documentReference.update("LonGM", value66 );
                        System.out.println("From Database "+LonVal);
                        //documentReference.update("LonGM", value66 );
                        //System.out.println("From Database "+LonVal);
//                SharedPreferences sp = getSharedPreferences("key", 0);
//                SharedPreferences.Editor sedt = sp.edit();
//                sedt.putString(value66, txtEvent.getText().toString());
//                sedt.putString("txtopertaive", txtOperative.getText().toString());
//                sedt.commit();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

                    }
                });
                //end of db calls

        //Reading from the SD
        db.collection("GPSresult")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData().toString());
                                String z = document.getData().toString();
                                System.out.println("Reading from database "+z);
                                Double valueA = document.getDouble("LatGM");
                                Double valueB = document.getDouble("LonGM");

                                System.out.println("Reading from database LAT "+valueA);
                                System.out.println("Reading from database LON "+valueB);
                                getGMlatLon(valueA,valueB);

                                System.out.println("HashMap after adding bonus marks:");
                                HashMap<String, Integer> hm =
                                        new HashMap<String, Integer>();
                                Iterator hmIterator = document.getData().entrySet().iterator();

                                while (hmIterator.hasNext()) {
                                    Map.Entry mapElement = (Map.Entry)hmIterator.next();
                                    Double marks = ((Double)mapElement.getValue());
                                    System.out.println(mapElement.getKey() + " : " + marks);
                                }
                            }
                        } else {
                            Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });
            }
        });


    }

    public void getMsg(String message) {
        Double gmLat = Double.parseDouble(message);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        final DocumentReference documentReference2 = db.collection("GPSresult").document("Values");
        final FirebaseDatabase database4 = FirebaseDatabase.getInstance();
        DatabaseReference myRef55 = database4.getReference();
        DatabaseReference myRef77 = database4.getReference();


        myRef55 = myRef55.child("Username").child("GPS").child("Latitude");
        myRef55.keepSynced(true);
        myRef55.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                Double value44 =  dataSnapshot.getValue(Double.class);
                LatVal = value44;
                getGMlat(value44);
                DecimalFormat df1 = new DecimalFormat("#.##");
                df1.format(value44);
                //TVlat.setText("Lat:  "+df1.format(value44));
                check = String.valueOf(value44);
                System.out.println("SHARED PREF VALUE DATA ON CHANGE = "+check);
                //TVlat.setText("26.46644");
                savedVal1 = "26.46644";
                sharedpreferences = getPreferences(Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("26.46644", check);
                editor.commit();
                documentReference2.update("LatGM",value44);
                if (value44 instanceof Double) {
                    System.out.println("object is a Double");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });


        mGMap = googleMap;
        //final DocumentReference documentReference2 = db.collection("GPSresult").document("Values");
        //Task<DocumentSnapshot> k = db.collection("GPSresult").document("Values").get();
        //System.out.println("From Firestore Database "+k);

        //Reading from the SD
        db.collection("GPSresult")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData().toString());
                                String z = document.getData().toString();
                                System.out.println("Reading from database "+z);
                                Double valueA = document.getDouble("LatGM");
                                Double valueB = document.getDouble("LonGM");

                                System.out.println("Reading from database LAT "+valueA);
                                System.out.println("Reading from database LON "+valueB);
                                //getGMlatLon(valueA,valueB);


                                System.out.println("HashMap after adding bonus marks:");
                                HashMap<String, Integer> hm =
                                        new HashMap<String, Integer>();
                                Iterator hmIterator = document.getData().entrySet().iterator();

                                while (hmIterator.hasNext()) {
                                    Map.Entry mapElement = (Map.Entry)hmIterator.next();
                                    Double marks = ((Double)mapElement.getValue());
                                    System.out.println(mapElement.getKey() + " : " + marks);
                                }
                            }
                        } else {
                            Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });


        gps = new GPSTracker(SeatLocation.this);

        //location = (TextView) findViewById(R.id.textView14);
        if (gps.canGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            String lat = Double.toString(latitude);
            String lon= Double.toString(longitude);
            // \n is for new line
            NumberFormat numberFormat = new DecimalFormat("#.##");
            //Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "
            //+ latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
            //location.setText("Lon: "+numberFormat.format(longitude)+ " Lat: " +numberFormat.format(latitude));
            //updateMap(gps.getLatitude(), gps.getLongitude());
        } else {
            gps.showSettingsAlert();
        }

       //Query mres = db.collection("GPSresult").whereGreaterThanOrEqualTo("LatGM", 26.27);

        mGMap.addMarker(new MarkerOptions()
                .position(new LatLng(26.5,-80.4 ))
                .title("ZACE Car Seat")
                //.snippet("It is located in France")
                //.rotation((float) 33.5)
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.carseat_in)));

        //Set Map Zoom
        mGMap.getUiSettings().setZoomGesturesEnabled(true);
        //LatLng mLoc = new LatLng(26.46, -80.07);
        LatLng FAU = new LatLng(26.3700, -80.1013);
        //LatLng GPSseat = new LatLng(LatVal, LonVal);
        //System.out.println(GPSseat);

        //Get your location weather
       //LatLng mLoc2 = new LatLng(gps.getLatitude(), gps.getLongitude());
        //Configure Map
        mGMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);


        // Add a marker in my location and move the camera
        UiSettings uiSettings = mGMap.getUiSettings();
        uiSettings.setIndoorLevelPickerEnabled(true);
        uiSettings.setMyLocationButtonEnabled(true);
        uiSettings.setMapToolbarEnabled(true);
        uiSettings.setCompassEnabled(true);
        uiSettings.setZoomControlsEnabled(true);
        uiSettings.setScrollGesturesEnabled(true);
        mGMap.addMarker(new MarkerOptions()
                //.position(new LatLng(26.8584,-80.1013 ))
                .position(FAU)
                .title("ZACE Car Seat")
                //.snippet("It is located in France")
                //.rotation((float) 33.5)
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.vsm_carseat_in)));
        //mGMap.addMarker(new MarkerOptions().position(FAU).title("ZACE Car Seat"));
        mGMap.moveCamera(CameraUpdateFactory.newLatLng(FAU));
        //moveCamera(mLoc2, 15);
        moveCamera(FAU, 15);
    }

    private void moveCamera(LatLng location, int zoom) {
        CameraPosition.Builder camBuilder = CameraPosition.builder();
        camBuilder.bearing(0);
        camBuilder.tilt(30);
        camBuilder.target(location);
        camBuilder.zoom(zoom);
        CameraPosition cp = camBuilder.build();
        mGMap.moveCamera(CameraUpdateFactory.newCameraPosition(cp));
    }



    private BitmapDescriptor bitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    public void Goback(View view){
        Intent inToDash = new Intent(getApplicationContext(), Dashboard.class);
        startActivity(inToDash);
        finish();
    }

    void getGMlat(Double gmlat){
        Double result1 =gmlat;
        System.out.println("Lat in getGMlat function "+result1);
    }

    void getGMlatLon(Double glat, Double glon){
        LatLng gpsModule = new LatLng(glat, glon);
        System.out.println("Lat Lon  function "+gpsModule);
        updateMap(glat,glon);

        //updateMap(41.505493,-81.681290);
        //GOOGLE MAPS
//        mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                .findFragmentById(R.id.map);
//        mapFragment.getMapAsync(this);
    }

    public void doSomething(Double Lat){

    }

    //final DocumentReference documentReference = db.collection("GPSresult").document("Values");
    //documentReference.update("LonGM", value66 );


    private void updateMap(double latitude, double longitude) {

/*      FirebaseFirestore db = FirebaseFirestore.getInstance();
        final DocumentReference documentReference2 = db.collection("GPSresult").document("Values");
        final FirebaseDatabase database4 = FirebaseDatabase.getInstance();
        DatabaseReference myRef55 = database4.getReference();
        DatabaseReference myRef77 = database4.getReference();


        myRef55 = myRef55.child("Username").child("GPS").child("Latitude");
        myRef55.keepSynced(true);
        myRef55.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                Double value44 =  dataSnapshot.getValue(Double.class);
                LatVal = value44;
                getGMlat(value44);
                DecimalFormat df1 = new DecimalFormat("#.##");
                df1.format(value44);
                TVlat.setText("Lat:  "+df1.format(value44));
                check = String.valueOf(value44);
                System.out.println("SHARED PREF VALUE DATA ON CHANGE = "+check);
                //TVlat.setText("26.46644");
                savedVal1 = "26.46644";
                sharedpreferences = getPreferences(Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("26.46644", check);
                editor.commit();
                documentReference2.update("LatGM",value44);
                if (value44 instanceof Double) {
                    System.out.println("object is a Double");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });*/


        LatLng newLocation = new LatLng(latitude, longitude);
        //Find information about the location
        Geocoder geocoder = new Geocoder(Objects.requireNonNull(mapFragment.getActivity()).getApplicationContext(), Locale.getDefault());

        //mGMap.addMarker(new MarkerOptions().position(newLocation)
                //.title("Longitude: " + longitude + " Latitude: " + latitude));
        mGMap.addMarker(new MarkerOptions()
                //.position(new LatLng(26.8584,-80.1013 ))
                .position(newLocation)
                .title("ZACE Car Seat")
                //.snippet("It is located in France")
                //.rotation((float) 33.5)
                .icon(bitmapDescriptorFromVector(getApplicationContext(),R.drawable.vsm_carseat_in)));

        moveCamera(newLocation, 18);
    }


}
