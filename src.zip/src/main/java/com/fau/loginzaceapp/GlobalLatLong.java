package com.fau.loginzaceapp;

import androidx.appcompat.app.AppCompatActivity;

public class GlobalLatLong extends AppCompatActivity {
    Double piLat;
    Double piLon;

    public GlobalLatLong(Double piLat, Double piLon) {
        this.piLat = piLat;
        this.piLon = piLon;
    }

    public GlobalLatLong(SeatLocation seatLocation) {
    }

    public Double getPiLon() {
        return piLon;
    }

    public Double getPiLat() {
        return piLat;
    }

    public GlobalLatLong() {
    }

    public void setPiLat(Double piLat) {
        this.piLat = piLat;
    }

    public void setPiLon(Double piLon) {
        this.piLon = piLon;
    }
}
