package com.fau.loginzaceapp;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

/**
 * Dashboard is responsible for data display & button controls
 * @author Alicia Mitchell
 */

public class Dashboard extends AppCompatActivity {

    final Context context = this;
    final Context context2 = this;
    final Context context3 = this;
    final Context context4 = this;
    final Context context5 = this;

    public static final String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE";
    TextView Display, TempRes, CMRes, GPSRes1, GPSRes2, VitalRes, uname;
    private static final String TAG = "Dashboard";
    DatabaseReference myDBref;
    //DatabaseReference myRef;
    ImageView seatState;
    ImageView logoff;
    ImageView one, two, three, stop, goToMap;
    ImageView blueStatus;
    Button btnStream, btnStopStream;
    //Button btnPlayMusic, btnStopMusic;
    Button btnRumble, btnRumbleOff;
    //private static final String TAG = "MainActivity";
    Integer i = 0;
    private FirebaseAuth mFireBaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        //Keep data persistent
        //FirebaseDatabase.getInstance().setPersistenceEnabled(true);
        // custom dialog
   /*     final Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialogbox);
        Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                //Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();*/


        //UI Elements Setup
        TempRes = findViewById(R.id.textTemp);
        CMRes = findViewById(R.id.textCM);
        GPSRes1 = findViewById(R.id.textGPS);
        GPSRes2 = findViewById(R.id.textView);
        VitalRes = findViewById(R.id.textView8);
        uname = findViewById(R.id.textView7);

        btnStream = findViewById(R.id.button6);
        //btnStopStream = findViewById(R.id.imageView11);
        //btnPlayMusic = findViewById(R.id.button);
        //btnStopMusic = findViewById(R.id.button4);
        btnRumble = findViewById(R.id.button14);
        btnRumbleOff = findViewById(R.id.button15);
        seatState = findViewById(R.id.imageView4);
        blueStatus = findViewById(R.id.imageView5);
        logoff = findViewById(R.id.imageView3);
        one = findViewById(R.id.imageView7);
        two = findViewById(R.id.imageView10);
        three = findViewById(R.id.imageView11);
        stop = findViewById(R.id.imageView12);
        goToMap = findViewById(R.id.ivMap);

        mFireBaseAuth = FirebaseAuth.getInstance();

        //Declaring DB instances
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final FirebaseDatabase database2 = FirebaseDatabase.getInstance();
        //Getting Reference to Root Node
        DatabaseReference myRef = database.getReference();
        DatabaseReference myRef2 = database2.getReference();
        DatabaseReference myRef3 = database2.getReference();
        DatabaseReference myRef4 = database2.getReference();
        DatabaseReference myRef5 = database2.getReference();
        DatabaseReference myRef6 = database2.getReference();
        DatabaseReference myRef7 = database2.getReference();
        DatabaseReference myRef8 = database2.getReference();

        //Getting reference to "Tvalue" node

        //works as is
        //myRef2 = myRef2.child("Username").child("userName");

        //Temp Value read from the database
        myRef2 = myRef2.child("Username").child("Tmp").child("Tvalue");
        //Keep Synced
        myRef2.keepSynced(true);
        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
                Double value =  dataSnapshot.getValue(Double.class);
                Toast.makeText(Dashboard.this, "Data Received: " + value, Toast.LENGTH_SHORT).show();
                DecimalFormat df1 = new DecimalFormat("#.##");
                df1.format(value);
                Double val = value;
                TempRes.setText("Temp:  "+df1.format(val)+"°C");
                //TempRes.setText("Temp:  "+value+"°C");
                //Save value for notification
                Double saveval = value;
                getTemp(saveval);
                if(value >= 80){
                    // custom dialog
                    final Dialog dialog = new Dialog(context);
                    dialog.setContentView(R.layout.dialogbox);
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            //Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
                        }
                    });
                    dialog.show();
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });

        //Vitals Value read from the database
        myRef3 = myRef3.child("Username").child("Vitals");
        //Keep Synced
        myRef3.keepSynced(true);
        myRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
                Double value2 =  dataSnapshot.getValue(Double.class);
                //Toast.makeText(MainActivity.this, "Data Received: " + value2, Toast.LENGTH_SHORT).show();
                DecimalFormat df2 = new DecimalFormat("#.##");
                df2.format(value2);
                VitalRes.setText("Vitals:  "+value2+"bps");
                if(value2 > 80){
                    // custom dialog
                    final Dialog dialog3 = new Dialog(context3);
                    dialog3.setContentView(R.layout.dialogbox_vitals);
                    Button dialogButton3 = (Button) dialog3.findViewById(R.id.dialogButtonOK3);
                    // if button is clicked, close the custom dialog
                    dialogButton3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog3.dismiss();
                            //Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
                        }
                    });
                    dialog3.show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });

        //Carbon Monoxide Status read from the database
        myRef4 = myRef4.child("Username").child("CM").child("CMstatus");
        //Keep Synced
        myRef4.keepSynced(true);
        myRef4.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
                Integer value3 =  dataSnapshot.getValue(Integer.class);
                //Toast.makeText(MainActivity.this, "Data Received: " + value3, Toast.LENGTH_SHORT).show();
                //CMRes.setText("CO:  "+Integer.toString(value3));
                if(value3.equals(0))
                {
                    CMRes.setText("CO:   SAFE");

                }
                else{
                    CMRes.setText("CO:   DANGER");
                       final Dialog dialog2 = new Dialog(context2);
                        dialog2.setContentView(R.layout.dialogbox_cm);
                        Button dialogButton2 = (Button) dialog2.findViewById(R.id.dialogButtonOK2);
                        // if button is clicked, close the custom dialog
                        dialogButton2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                dialog2.dismiss();
                                //Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
                            }
                        });
                        dialog2.show();



                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });

        //GPS Values read from the database
        myRef5 = myRef5.child("Username").child("GPS").child("Latitude");
        //Keep Synced
        myRef5.keepSynced(true);
        myRef5.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
               Double value4 =  dataSnapshot.getValue(Double.class);
                if (value4 instanceof Double) {
                    System.out.println("object is a Double");
                   }
//                //Toast.makeText(MainActivity.this, "Data Received: " + value4, Toast.LENGTH_SHORT).show();
                DecimalFormat df3 = new DecimalFormat("#.##");
                Double val4 = value4;
                df3.format(value4);
                // GPSRes1.setText("Lat:  "+value4);
                GPSRes1.setText("Lat:  "+df3.format(val4));

                //getVal4(value4);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });

        //GPS Values read from the database
        myRef7 = myRef7.child("Username").child("GPS").child("Longitude");
        //Keep Synced
        myRef7.keepSynced(true);
        myRef7.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
                Double value6 =  dataSnapshot.getValue(Double.class);
                DecimalFormat df4 = new DecimalFormat("#.##");
                df4.format(value6);
                Double val6 =value6;
                //Toast.makeText(MainActivity.this, "Data Received: " + value6, Toast.LENGTH_SHORT).show();
                GPSRes2.setText("Lon:  "+df4.format(val6));
                //GPSRes2.setText("Lon:  "+value6);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });

        //Seat Status Value read from the database
        myRef8 = myRef8.child("Username").child("Pressure").child("Sstatus");
        //Keep Synced
        myRef8.keepSynced(true);
        myRef8.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
                //String value6 =  dataSnapshot.getValue(String.class);
                //Toast.makeText(MainActivity.this, "Data Received: " + value6, Toast.LENGTH_SHORT).show();
                Integer value10 =  dataSnapshot.getValue(Integer.class);
                //Toast.makeText(MainActivity.this, "Data Received: " + value3, Toast.LENGTH_SHORT).show();
                //CMRes.setText("CO:  "+Integer.toString(value3));
                getSeatStatus(value10);
                if(value10.equals(0))
                {
                    seatState.setImageResource(R.drawable.carseat_out1);
                }
                else{
                    seatState.setImageResource(R.drawable.carseat_in);
                    final BroadcastReceiver mReceiverB = new BroadcastReceiver() {
                        @Override
                        public void onReceive(Context context, Intent intent) {
                            String action = intent.getAction();
                            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                            //vibration
                            if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                                seatState.setImageResource(R.drawable.bluetooth_off);

                                final Dialog dialog4 = new Dialog(context4);
                                dialog4.setContentView(R.layout.dialogbox_blue);
                                Button dialogButton4 = (Button) dialog4.findViewById(R.id.dialogButtonOK4);
                                // if button is clicked, close the custom dialog
                                dialogButton4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog4.dismiss();
                                        //Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
                                    }
                                });
                                dialog4.show();

                            }
                        }
                    };
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });


        myRef6 = myRef6.child("Username").child("userName");
        //Keep Synced
        myRef6.keepSynced(true);
        myRef6.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //Getting the string value of that node
                //String value =  dataSnapshot.getValue(String.class);
                String value5 =  dataSnapshot.getValue(String.class);
                //Toast.makeText(MainActivity.this, "Data Received: " + value5, Toast.LENGTH_SHORT).show();
                uname.setText(value5);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "onCancelled: Something went wrong! Error:" + databaseError.getMessage() );

            }
        });



        //Writing to the database
        //Setting Value Updating a value in the DB
        DatabaseReference myRef9 = database2.getReference();
        myRef9.child("Username").child("SongChoice").setValue(0);

        DatabaseReference myRef10 = database2.getReference();
        myRef10.child("Username").child("VideoStatus").setValue(0);

        DatabaseReference myRef11 = database2.getReference();
        myRef11.child("Username").child("Vibration").setValue(0);

        //Writing to the database
        //WORKING
     /*   btnPlayMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef9 = database.getReference();
                myRef9.child("Username").child("SongChoice").setValue(1);
            }
        });*/

       //Music controls
       one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef9 = database.getReference();
                myRef9.child("Username").child("SongChoice").setValue(1);
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef9 = database.getReference();
                myRef9.child("Username").child("SongChoice").setValue(2);
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef9 = database.getReference();
                myRef9.child("Username").child("SongChoice").setValue(3);
            }
        });

/*       next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i++;
                Handler handler = new Handler();
                Runnable runn = new Runnable() {
                    @Override
                    public void run() {
                        i =0;
                    }
                };
                if(i==1)
                {
                    System.out.println("Button clicked "+i+" time");
                    handler.postDelayed(runn, 5000);
                    DatabaseReference myRef9 = database.getReference();
                    myRef9.child("Username").child("SongChoice").setValue(2);
                }
                else if(i==2){
                    System.out.println("Button clicked "+i+" times");
                    DatabaseReference myRef9 = database.getReference();
                    myRef9.child("Username").child("SongChoice").setValue(3);
                }
                else if(i==3){
                    System.out.println("Button clicked "+i+" times");
                    DatabaseReference myRef9 = database.getReference();
                    myRef9.child("Username").child("SongChoice").setValue(1);
                }
                else if(i==4){
                    System.out.println("Button clicked "+i+" times");
                    DatabaseReference myRef9 = database.getReference();
                    myRef9.child("Username").child("SongChoice").setValue(1);
                    i=0;
                }
            }
        });*/

    /*    //WORKING
        btnStopMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef9 = database.getReference();
                myRef9.child("Username").child("SongChoice").setValue(0);

            }
        });*/

        //Stop Music
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef9 = database.getReference();
                myRef9.child("Username").child("SongChoice").setValue(0);

            }
        });

        //Start Streaming Video
        btnStream.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef10 = database.getReference();
                myRef10.child("Username").child("VideoStatus").setValue(1);
                Intent inToVidStream = new Intent(getApplicationContext(), VideoStream.class);
                startActivity(inToVidStream);
                finish();
            }
        });

//        //WORKING
//        btnStopStream.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                DatabaseReference myRef10 = database.getReference();
//                myRef10.child("Username").child("VideoStatus").setValue(0);
//
//            }
//        });

        //Start Rumble
        btnRumble.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef11 = database.getReference();
                myRef11.child("Username").child("Vibration").setValue(1);

            }
        });

        //Stop Rumble
        btnRumbleOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference myRef11 = database.getReference();
                myRef11.child("Username").child("Vibration").setValue(0);

            }
        });

        //Go to Map activity
        goToMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inToMap = new Intent(getApplicationContext(), SeatLocation.class);
                inToMap.putExtra(EXTRA_MESSAGE, 26.5);
                startActivity(inToMap);
                finish();
            }
        });

        //Logout
        logoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
                // Method that allows you to logout via  logout button
                mFireBaseAuth.getInstance().signOut();
                Intent inToMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(inToMain);
                finish();

            }
        });


    }

    void getTemp(Double tempNow){
        Double result1 =tempNow;
        System.out.println(result1);
    }
    void getSeatStatus(Integer occupied){
        Integer result5 =occupied;
        System.out.println(" SEAT STATUS = " +result5);
    }

    /**
     * Dashboard area where bluetooth connection is tested
     * @author Eric Piasentin
     */

    //Bluetooth Setup
    final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
            } else if (BluetoothDevice.ACTION_ACL_CONNECTED.equals(action)) {
                //
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        context);

                // set title
                alertDialogBuilder.setTitle("Bluetooth Status!");

                // set dialog message
                alertDialogBuilder
                        .setMessage("You are connected via Bluetooth!")
                        .setCancelable(false)
                        .setPositiveButton("OK!", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // if this button is clicked, close
                                // current activity
                                //MainActivity.this.finish();
                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECT_REQUESTED.equals(action)) {
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(action)) {
                seatState.setImageResource(R.drawable.bluetooth_off);
                final Dialog dialog5 = new Dialog(context5);
                dialog5.setContentView(R.layout.dialog_blue_noconnection);
                Button dialogButton5 = (Button) dialog5.findViewById(R.id.dialogButtonOK5);
                // if button is clicked, close the custom dialog
                dialogButton5.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog5.dismiss();
                        //Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
                    }
                });
                dialog5.show();
            }
        }
    };


}
