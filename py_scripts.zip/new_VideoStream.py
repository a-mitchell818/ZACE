#!/usr/bin/env python3
#camera libraries for the video streaming
#use inet address to view streaming camera video http://ip address:8000
#must include script seperately or execute code to turn on and off video stream
# Firebase Setup............................................................................
import pyrebase

config = {
  "apiKey": "AIzaSyBLwqnVX1GjE1n6SH-kRlPA6Mro7EdNUSE",
  "authDomain": "zaceconnectv1.firebaseapp.com",
  "databaseURL": "https://zaceconnectv1.firebaseio.com",
  "storageBucket": "zaceconnectv1.appspot.com"
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()

VideoStatus=1
db.child("Username").child("VideoStatus").set(VideoStatus)

def video():
    import io
    import picamera
    import logging
    import socketserver
    from threading import Condition
    from http import server

    #Html page to send video stream to
    PAGE="""\
    <html>
    <head>
    <title>ZACE Smart Child Car Seat</title>
    </head>
    <body>
    <center><h1>ZACE Smart Child Car Seat</h1></center>
    <center><img src="stream.mjpg" width="640" height="480"></center>
    </body>
    </html>
    """

    class StreamingOutput(object):
        def __init__(self):
            self.frame = None
            self.buffer = io.BytesIO()
            self.condition = Condition()

        def write(self, buf):
            if buf.startswith(b'\xff\xd8'):
                # given new frame then have buffer's content be copied
            # Indicate to all its availability to all clients
                self.buffer.truncate()
                with self.condition:
                    self.frame = self.buffer.getvalue()
                    self.condition.notify_all()
                self.buffer.seek(0)
            return self.buffer.write(buf)

    #Handles http requests for streaming
    class StreamingHandler(server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/':
                self.send_response(301)
                self.send_header('Location', '/index.html')
                self.end_headers()
            elif self.path == '/index.html':
                content = PAGE.encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'text/html')
                self.send_header('Content-Length', len(content))
                self.end_headers()
                self.wfile.write(content)
            elif self.path == '/stream.mjpg':
                self.send_response(200)
                self.send_header('Age', 0)
                self.send_header('Cache-Control', 'no-cache, private')
                self.send_header('Pragma', 'no-cache')
                self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=FRAME')
                self.end_headers()
                try:
                    while True:
                        with output.condition:
                            output.condition.wait()
                            frame = output.frame
                        self.wfile.write(b'--FRAME\r\n')
                        self.send_header('Content-Type', 'image/jpeg')
                        self.send_header('Content-Length', len(frame))
                        self.end_headers()
                        self.wfile.write(frame)
                        self.wfile.write(b'\r\n')
                except Exception as e:
                    logging.warning(
                        'Removed streaming client %s: %s',
                        self.client_address, str(e))
            else:
                self.send_error(404)
                self.end_headers()

    class StreamingServer(socketserver.ThreadingMixIn, server.HTTPServer):
        allow_reuse_address = True
        daemon_threads = True

    #Setup for pi camera video resolution, framerate, and server
    with picamera.PiCamera(resolution='640x480', framerate=24) as camera:
        output = StreamingOutput()
        #Adjust Pi's Camera rotation if needed
        camera.rotation = 90
        camera.start_recording(output, format='mjpeg')
        try:
            address = ('', 8000)
            server = StreamingServer(address, StreamingHandler)
            server.serve_forever()
        finally:
            camera.stop_recording()

VideoStatus=db.child("Username").child("VideoStatus").get().val()
if VideoStatus == 1:
    video()

elif VideoStatus == 0:
    camera.stop_recording()