#!/usr/bin/env python3
import RPi.GPIO as GPIO
import time
import serial
import os # for ds18b20 internal temp sensor
import glob # for ds18b20
import busio
import digitalio
import board
import adafruit_mcp3xxx.mcp3008 as MCP
import pyrebase
from adafruit_mcp3xxx.analog_in import AnalogIn
import vlc
GPIO.setmode(GPIO.BCM)		#to specify which pin numbering system




# Firebase Setup............................................................................
config = {
  "apiKey": "AIzaSyBLwqnVX1GjE1n6SH-kRlPA6Mro7EdNUSE",
  "authDomain": "zaceconnectv1.firebaseapp.com",
  "databaseURL": "https://zaceconnectv1.firebaseio.com",
  "storageBucket": "zaceconnectv1.appspot.com"
}

firebase = pyrebase.initialize_app(config)
db = firebase.database()

# End Firebase setup........................................................................


# Setup for MCP..............................................................................
spi = busio.SPI(clock=board.SCK, MISO=board.MISO, MOSI=board.MOSI)
cs = digitalio.DigitalInOut(board.CE0)
mcp = MCP.MCP3008(spi, cs)
chan1=AnalogIn(mcp, MCP.P1) # Pressure
chan2=AnalogIn(mcp, MCP.P2) # MQ-7
# End setup for MCP.........................................................................

#setup for GPIO pins........................................................................
vibration_gpio = 16
fan_gpio = 23
interrupt = 0
# End setup for GPIO pins...................................................................

#Setup for internal fan and vibration motor.................................................
GPIO.setwarnings(False)
GPIO.setup(vibration_gpio, GPIO.OUT) #config for vibration motor
GPIO.setup(fan_gpio, GPIO.OUT) # GPIO18 set to output for fan
# End setup for internal fan and vibration motor............................................

#Setup for ds18b20 temp sensor..............................................................
os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'
# end setup for ds18b20 temp sensor.........................................................

#Setup for GPS module.......................................................................
ser = serial.Serial(
         port ='/dev/ttyS0',
         baudrate = 9600,
         parity = serial.PARITY_NONE,
         stopbits = serial.STOPBITS_ONE,
         bytesize = serial.EIGHTBITS,
         timeout = 1
         )
# End setup for GPS.........................................................................

#Setup for Pulse Sensor.....................................................................
serPulse = serial.Serial('/dev/ttyUSB0',9600,timeout=1)
serPulse.flush()
#End Setup for Pulse Sensor.................................................................

# Begin Setup for Audio.....................................................................
# songs from https://www.johnsonsbabyarabia.com/en/bedtime/lullabies
instance = vlc.Instance('--aout=alsa')
player = instance.media_player_new()
vlc.libvlc_audio_set_volume(player, 100)
# End setup for audio.......................................................................

#Function Definitions.......................................................................
def init():
    Tval = 0
    db.child("Username").child("Tmp").child("Tvalue").set(Tval)
    Tstate = 0
    db.child("Username").child("Tmp").child("Tstatus").set(Tstate)
    CMstate = 0
    db.child("Username").child("CM").child("CMstatus").set(CMstate)
    Sstate = 0
    db.child("Username").child("Pressure").child("Sstatus").set(Sstate)
    LongitudeNWSE = "-"
    LatitudeNWSE = "+"
    LonVal = 0
    LatVal = 0
    GroundSpeed = 0
    db.child("Username").child("GPS").child("Longitude").set(LonVal)
    db.child("Username").child("GPS").child("Latitude").set(LonVal)
    db.child("Username").child("GPS").child("GndSpeed").set(GroundSpeed)
    db.child("Username").child("GPS").child("NWSELon").set(LongitudeNWSE)
    db.child("Username").child("GPS").child("NWSELat").set(LatitudeNWSE)
    BPMval = 0
    db.child("Username").child("Vitals").set(BPMval)
    motorStatus= 0
    db.child("Username").child("Vibration").set(motorStatus)
    currentSong = 0
    db.child("Username").child("SongChoice").set(currentSong)
    PowerStatus = 0
    db.child("Username").child("ShutDown").set(PowerStatus)


def vibration(x):
    if x==1:
        GPIO.output(vibration_gpio, GPIO.HIGH)
    else:
        GPIO.output(vibration_gpio, GPIO.LOW)

def read_temp_raw(): #internal temp
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines

def read_temp(): #internal temp
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        temp_f = temp_c * 9.0 / 5.0 + 32.0

        if (temp_f >= 80):
            Temp_flag = 1
        else:
            Temp_flag = 0
        return temp_f, Temp_flag
    else:
        temp_f = "error"
        Temp_flag = "error"
        return temp_f, Temp_flag


def fan_control(temp):
    if temp > 80:
        GPIO.output(fan_gpio, GPIO.HIGH)
    else:
         GPIO.output(fan_gpio, GPIO.LOW)

def COLevel(interrupt):
    COlevel = chan2.voltage
    #print("Co voltage = ",COlevel)



    if   (COlevel > float(0.2)):
        #print("CO Level Danger")
        #global interrupt
        interrupt = 0
        return 1, interrupt
    elif  (interrupt == 0):
        #print("CO at Safe Level")
        #global interrupt
        interrupt = 1
        return 0, interrupt

    return None, None

def GPS():
    x=ser.readline()
    #print(x)
    return x
    #GPRMC xxxxxx.xxx,A,26  16 .2874,N,  080 11 .5757,W,    .29
    #        time    OK Deg min  sec Lat deg min sec  Long   Groundspd Knots

#Parses contents of $GPRMC String & formats for google
def parseGPS(gpsString):
    if gpsString[0:8] == "b'$GPRMC":
        sgpsString = gpsString.split(",")
        if sgpsString[2] == 'V':
            lon = "error"
            lat = "error"
            dirLat = "error"
            dirLon = "error"
            speed = "error"
            print( "satellite data is unavailable")
            return lon, lat, dirLat, dirLon, speed
        lat = decodeIt(sgpsString[3]) #Get latitude
        dirLat = sgpsString[4]      #Get latitude direction N/S
        lon = decodeIt(sgpsString[5]) #Get longitude
        dirLon = sgpsString[6]      #Get longitude direction E/W
        if(sgpsString[4] == "N"):
            gmdeglat = "+"+lat[0:2]+" "+lat[7:14]
        else:
            gmdeglat = "-"+lat[0:2]+" "+lat[7:14]
        if(sgpsString[6] == "E"):
            gmdeglon = "+"+lon[0:2]+" "+lon[7:14]
        else:
            gmdeglon = "-"+lon[0:2]+" "+lon[7:14]
        speed = sgpsString[7]       #Speed (knots)
        trCourse = sgpsString[8]    #True course
        #print ("latitude : %s(%s), longitude : %s(%s), speed : %s, True Course : %s" %  (lat,dirLat,lon,dirLon,speed,trCourse))
        return lon, lat, dirLat, dirLon, speed

    return None, None, None, None, None

#Extracts the longitude and Latitude from the $GPRMC String
def decodeIt(coord):
    #Converts DDDMM.MMMMM > DD deg MM.MMMMM min
    x = coord.split(".")
    head = x[0]
    tail = x[1]
    if (len(head) == 5):
        deg = head[1:-2]
        min = head[-2:]
        return deg + " deg " + min + "." + tail + " min"
    deg = head[0:-2]
    min = head[-2:]
    return deg + " deg " + min + "." + tail + " min"



def Pressure():


    if(chan1.voltage < 1.5):
        pressure_Input = 0
    if(chan1.voltage >= 1.5):

        pressure_Input = 1

    return pressure_Input


def song_select(s):

    player.stop()
    if s==0:
        player.stop()
    elif s==1:
        twinkle = instance.media_new('rockabyebaby.mp3')
        player.set_media(twinkle)
        player.play()
    elif s==2:
        goodNight = instance.media_new('lullabygoodnight.mp3')
        player.set_media(goodNight)
        player.play()
    elif s==3:
        horses = instance.media_new('prettylittlehorses.mp3')
        player.set_media(horses)
        player.play()

def pulseSensor():

    if serPulse.in_waiting > 0:
        line = serPulse.readline().decode('utf-8').rstrip()
        linestr=str(line)
        if not linestr.startswith('\x00'):
            BPM = int(line)
            return BPM

def shutdown():
    command = "/usr/bin/sudo /sbin/shutdown -h now"
    import subprocess
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
    output = process.communicate()[0]


# End Function definitions...................................................................

#Main Function...............................................................................
def main():
         init()
         print("please wait...")
         time.sleep(2)


         #Variable Declaration...............................................................
         motorStatus = 0
         global interrupt
         interrupt = 0
         pressure_Input = 0
         prev_input = 0
         currentTime = time.time()
         baby = 0
         songChoice = 0
         currentSong=0
         BPMtotal = 0
         BPMcount = 0
         countsAvg = 15

         #End Variable Declaration..........................................................



         #Main Loop..........................................................................
         while True:

             COSafe, interrupt = COLevel(interrupt)
             if(COSafe is not None and interrupt is not None):
                db.child("Username").child("CM").update({"CMstatus": COSafe}) #this will be changed to send to database




             LonSTATE, LatSTATE, LatDir, LonDir, gsSTATE = parseGPS(str(GPS()))
             if( LonSTATE is not None):
                db.child("Username").child("GPS").update({"Longitude": LonSTATE})
                db.child("Username").child("GPS").update({"Latitude": LatSTATE})
                db.child("Username").child("GPS").update({"NWSELon": LonDir})
                db.child("Username").child("GPS").update({"NWSELat": LatDir})
                db.child("Username").child("GPS").update({"GndSpeed": gsSTATE})

             #print(str(GPS()))
             #print(gpsString)
             #vibration(motorStatus)



             externalTemp,Tflag = read_temp()
             fan_control(externalTemp)
             db.child("Username").child("Tmp").update({"Tstatus": Tflag})
             db.child("Username").child("Tmp").update({"Tvalue": externalTemp})

             p = Pressure()

             if((not prev_input) and p): #if there was no pressure before and now there is
                baby = 1

             if((not p) and prev_input): #if there was pressure before and now there is not
                baby = 0

             prev_input = p
             db.child("Username").child("Pressure").update({"Sstatus": baby})

             currentSong = songChoice
             songChoice = db.child("Username").child("SongChoice").get().val()
             if currentSong != songChoice:
                 song_select(songChoice)


             motorStatus = db.child("Username").child("Vibration").get().val()
             #print ("Rumble On (1) Vibration Off (0) ", motorStatus)
             vibration(motorStatus)

             BPM = pulseSensor()

             if BPM is not None:
                BPMtotal = BPMtotal + BPM
                print ("Current BPM = ", BPM)
                BPMcount += 1


             if(BPMcount==countsAvg):
                 BPMavg = BPMtotal/countsAvg

                 if BPMavg > 150 or BPMavg < 50:
                     BPMavg = 0.0
                     db.child("Username").update({"Vitals": BPMavg})
                     print("error") # this statement will be send to database
                 else:
                     db.child("Username").update({"Vitals": BPMavg})
                     print("Average BPM =", BPMavg) #this statement will be send to database
                 BPMtotal = 0
                 BPMcount = 0


             PowerStatus= db.child("Username").child("ShutDown").get().val()
             if PowerStatus == 1:
                 shutdown()





if __name__ =='__main__':
         try:
                  main()
                  pass
         except KeyboardInterrupt:
                  pass


GPIO.cleanup()